package utils;

public class UltimoDigitoNoLetraException extends Exception{
    public UltimoDigitoNoLetraException() {
    }

    public UltimoDigitoNoLetraException(String message) {
        super(message);
    }
}
