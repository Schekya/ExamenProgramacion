package utils;

public class LongitudDNINoValidaException extends Exception{
    public LongitudDNINoValidaException() {
    }

    public LongitudDNINoValidaException(String message) {
        super(message);
    }
}
